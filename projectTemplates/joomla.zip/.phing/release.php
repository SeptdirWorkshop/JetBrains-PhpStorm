<?php
require_once "phing/Task.php";

class release extends Task
{
	/**
	 * The version passed in the buildfile.
	 */
	private $task = null;

	/**
	 * The task title passed in the buildfile.
	 */
	private $title = null;

	/**
	 * The version passed in the buildfile.
	 */
	private $version = null;

	/**
	 * Set Task for the attribute "task"
	 *
	 * @param string $name Task name
	 */
	public function setTask($name)
	{
		$this->task = $name;
	}

	/**
	 * Set Version for the attribute "version"
	 *
	 * @param string $version Version number
	 */
	public function setVersion($version)
	{
		$this->version = $version;
	}

	/**
	 * Set Version for the attribute "title"
	 *
	 * @param string $title Task title
	 */
	public function setTitle($title)
	{
		$this->title = $title;
	}

	public function changeVersion()
	{
		$directory     = '../';
		$exclude       = array('.git', '.phing', '.idea', '.packages');
		$filter        = function ($file, $key, $iterator) use ($exclude) {
			if ($iterator->hasChildren() && !in_array($file->getFilename(), $exclude))
			{
				return true;
			}

			return $file->isFile();
		};
		$innerIterator = new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS);
		$iterator      = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator($innerIterator, $filter));
		$files         = array();
		foreach ($iterator as $filename => $info)
		{
			$context = file_get_contents($filename);
			$context = preg_replace('/@version    (.?)*/', '@version    ' . $this->version, $context);
			$context = preg_replace('/\<version\>(.?)*<\/version\>/',
				'<version>' . $this->version . '</version>', $context);
			$context = preg_replace('/\<creationDate>(.?)*<\/creationDate\>/',
				'<creationDate>' . date('F Y') . '</creationDate>', $context);
			file_put_contents($filename, $context);
		}
		foreach (array_slice(scandir('../.idea/copyright'), 2) as $file)
		{
			$filename = '../.idea/copyright/' . $file;
			$context  = file_get_contents($filename);
			$context  = preg_replace('/@version.+?\&#10;/', '@version    ' . $this->version . '&#10;', $context);
			file_put_contents($filename, $context);
		}
		echo 'Version changed to ' . $this->version;
	}

	public function main()
	{
		$task    = $this->task;
		$title   = $this->title;
		$version = $this->version;

		echo $title . ' ' . $version . PHP_EOL;

		$this->$task();
	}
}


