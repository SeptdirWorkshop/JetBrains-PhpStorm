<?php

class release extends Task
{
	/**
	 * The version passed in the buildfile.
	 *
	 * @var string
	 */
	protected $task = null;

	/**
	 * The name passed in the buildfile.
	 *
	 * @var string
	 */
	protected $name = null;

	/**
	 * The version passed in the buildfile.
	 *
	 * @var string
	 */
	protected $version = null;

	/**
	 * The package passed in the buildfile.
	 *
	 * @var string
	 */
	protected $package = null;

	/**
	 * Set task for the attribute "task"
	 *
	 * @param string $task Task name
	 */
	public function setTask($task)
	{
		$this->task = $task;
	}

	/**
	 * Set Name for the attribute "name"
	 *
	 * @param string $name Project name
	 */
	public function setName($name)
	{
		$this->name = $name;
	}

	/**
	 * Set version for the attribute "version"
	 *
	 * @param string $version Version number
	 */
	public function setVersion($version)
	{
		$this->version = $version;
	}

	/**
	 * Set package for the attribute "package"
	 *
	 * @param string $package package file name
	 */
	public function setPackage($package)
	{
		$this->package = $package;
	}

	/**
	 * Main function
	 */
	public function main()
	{
		$task = $this->task;
		$this->$task();
	}

	/**
	 * Method to show project information
	 *
	 * @return void
	 */
	public function showInfo()
	{
		echo
			'@name     ' . $this->name . PHP_EOL .
			'@version  ' . $this->version . PHP_EOL .
			'@package  ' . $this->package . PHP_EOL;
	}

	/**
	 * Method to change project version in files
	 *
	 * @return void
	 */
	protected function changeVersion()
	{
		// Change version in project files
		$files = $this->getFiles('../', array('.git', '.idea', '.packages', '.phing', '.gitignore', 'LICENSE', '*.md'));
		foreach ($files as $filename)
		{
			$original = file_get_contents($filename);
			$replace  = preg_replace('/@version(.?)*/', '@version    ' . $this->version, $original);
			$replace  = preg_replace('/\<version\>(.?)*<\/version\>/',
				'<version>' . $this->version . '</version>', $replace);
			$replace  = preg_replace('/\<creationDate>(.?)*<\/creationDate\>/',
				'<creationDate>' . date('F Y') . '</creationDate>', $replace);

			if ($original != $replace)
			{
				file_put_contents($filename, $replace);
			}
		}

		// Change version in idea copyrights
		$files = $this->getFiles('../.idea/copyright', array('profiles_settings.xml'));
		foreach ($files as $filename)
		{
			$original = file_get_contents($filename);
			$replace  = preg_replace('/@version.+?\&#10;/', '@version    ' . $this->version . '&#10;', $original);

			if ($original != $replace)
			{
				file_put_contents($filename, $replace);
			}
		}
		echo 'Version changed to ' . $this->version . PHP_EOL;

		return;
	}

	/**
	 * Method to  create package archive file
	 *
	 * @return void
	 */
	protected function createPackage()
	{
		$packages_directory = '../.packages/';
		$package_file       = $packages_directory . $this->package;

		// Remove old archive
		if (file_exists($package_file))
		{
			unlink($package_file);
		}

		// Create new archive
		$zip = new ZipArchive();
		if ($zip->open($package_file, ZIPARCHIVE::CREATE) !== true)
		{
			echo '! Package ' . $this->package . ' error: Error while creating archive file ' . PHP_EOL;

			return;
		}

		// Add files to archive
		$files = $this->getFiles('../', array('.git', '.idea', '.packages', '.phing', '.gitignore', 'LICENSE', '*.md'));
		foreach ($files as $file => $filename)
		{
			$zip->addFile($filename, $file);
		}

		// Close archive
		$zip->close();

		echo 'Package ' . $this->package . ' was created ' . PHP_EOL;

		return;
	}

	/**
	 * Method to get Files
	 *
	 * @param string $directory path to directory
	 * @param array  $exclude   files and directory files
	 *
	 * @return array files path list
	 */
	protected function getFiles($directory = '../', $exclude = array())
	{
		$directory_path     = realpath($directory);
		$exclude_extensions = array();
		foreach ($exclude as $value)
		{
			if (preg_match('/\*./', $value, $matches))
			{
				$exclude_extensions[] = str_replace('*.', '', $value);
			}
		}

		// Catalog filter
		$filter = function ($file, $key, $iterator) use ($exclude) {
			if ($iterator->hasChildren() && !in_array($file->getFilename(), $exclude))
			{
				return true;
			}

			return $file->isFile();
		};

		$innerIterator = new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS);
		$iterator      = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator($innerIterator, $filter));

		$files = array();

		foreach ($iterator as $filename => $info)
		{
			if (!in_array($info->getFilename(), $exclude) && !in_array($info->getExtension(), $exclude_extensions))
			{
				$clear_path = trim(str_replace($directory_path, '', $info->getRealPath()), '/\\');

				$files[$clear_path] = $filename;
			}
		}

		return $files;
	}
}


